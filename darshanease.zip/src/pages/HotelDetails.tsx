import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, addDoc, serverTimestamp, query, where, getDocs, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Hotel } from './TempleDetails';
import { Calendar as CalendarIcon, ArrowLeft, Building, CreditCard, Star, User, MessageSquare, ChevronLeft, ChevronRight } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { format, addDays } from 'date-fns';

interface HotelReview {
  id: string;
  hotelId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: any;
}

export const HotelDetails = () => {
  const { id } = useParams<{ id: string }>();
  const [hotel, setHotel] = useState<Hotel & { amenities?: string[] } | null>(null);
  const [reviews, setReviews] = useState<HotelReview[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  // Booking state
  const [checkInDate, setCheckInDate] = useState(format(addDays(new Date(), 1), 'yyyy-MM-dd'));
  const [checkOutDate, setCheckOutDate] = useState(format(addDays(new Date(), 2), 'yyyy-MM-dd'));
  const [numberOfRooms, setNumberOfRooms] = useState(1);
  const [roomBookingLoading, setRoomBookingLoading] = useState(false);

  // Review state
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  // Gallery state
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handlePrevImage = () => {
    if (!hotel?.imageUrls || hotel.imageUrls.length <= 1) return;
    setCurrentImageIndex((prev) => (prev === 0 ? hotel.imageUrls!.length - 1 : prev - 1));
  };

  const handleNextImage = () => {
    if (!hotel?.imageUrls || hotel.imageUrls.length <= 1) return;
    setCurrentImageIndex((prev) => (prev === hotel.imageUrls!.length - 1 ? 0 : prev + 1));
  };

  useEffect(() => {
    const fetchHotel = async () => {
      if (!id) return;
      try {
        const docRef = doc(db, 'hotels', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setHotel({ id: docSnap.id, ...docSnap.data() } as Hotel);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `hotels/${id}`);
      } finally {
        setLoading(false);
      }
    };

    fetchHotel();

    if (id) {
      const q = query(collection(db, 'hotel_reviews'), where('hotelId', '==', id));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const reviewsData = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as HotelReview[];
        
        // Sort manually as we might not have a composite index for hotelId + createdAt
        reviewsData.sort((a, b) => {
          const timeA = a.createdAt?.toMillis ? a.createdAt.toMillis() : 0;
          const timeB = b.createdAt?.toMillis ? b.createdAt.toMillis() : 0;
          return timeB - timeA;
        });
        
        setReviews(reviewsData);
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'hotel_reviews');
      });

      return () => unsubscribe();
    }
  }, [id]);

  const handleRoomBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert('Please login to book a room.');
      return;
    }
    if (!hotel) return;

    setRoomBookingLoading(true);
    try {
      const checkIn = new Date(checkInDate);
      const checkOut = new Date(checkOutDate);
      const diffTime = Math.abs(checkOut.getTime() - checkIn.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      const nights = diffDays > 0 ? diffDays : 1;
      const totalPrice = hotel.pricePerNight * nights * numberOfRooms;

      const bookingRef = await addDoc(collection(db, 'room_bookings'), {
        userId: user.uid,
        hotelId: hotel.id,
        checkInDate,
        checkOutDate,
        numberOfRooms,
        totalPrice,
        status: 'pending',
        createdAt: serverTimestamp(),
      });

      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: totalPrice,
          title: `Booking at ${hotel.name}`,
          bookingId: bookingRef.id,
          type: 'room',
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create checkout session');
      }

      const { id: sessionId } = await response.json();

      const stripe = window.Stripe((import.meta as any).env.VITE_STRIPE_PUBLIC_KEY);
      if (stripe) {
        await stripe.redirectToCheckout({ sessionId });
      } else {
        throw new Error('Stripe failed to initialize');
      }
    } catch (error) {
      console.error('Room booking error:', error);
      alert('Failed to initiate booking. Please try again.');
    } finally {
      setRoomBookingLoading(false);
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert('Please login to submit a review.');
      return;
    }
    if (!hotel || !comment.trim()) return;

    setSubmittingReview(true);
    try {
      await addDoc(collection(db, 'hotel_reviews'), {
        hotelId: hotel.id,
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        rating,
        comment: comment.trim(),
        createdAt: serverTimestamp(),
      });
      setComment('');
      setRating(5);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'hotel_reviews');
    } finally {
      setSubmittingReview(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  if (!hotel) {
    return <div className="text-center py-12 text-gray-500">Hotel not found.</div>;
  }

  const averageRating = reviews.length > 0 
    ? (reviews.reduce((acc, rev) => acc + rev.rating, 0) / reviews.length).toFixed(1)
    : 'New';

  return (
    <div className="max-w-5xl mx-auto">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center text-orange-600 hover:text-orange-800 mb-6 font-medium"
      >
        <ArrowLeft className="w-4 h-4 mr-1" /> Back
      </button>

      <div className="bg-white rounded-2xl shadow-lg overflow-hidden flex flex-col md:flex-row mb-8">
        <div className="md:w-1/2 flex flex-col">
          <div className="h-64 md:h-80 relative group">
            <img
              src={hotel.imageUrls && hotel.imageUrls.length > 0 ? hotel.imageUrls[currentImageIndex] : 'https://picsum.photos/seed/hotel/800/600'}
              alt={hotel.name}
              className="w-full h-full object-cover transition-opacity duration-300"
              referrerPolicy="no-referrer"
            />
            {hotel.imageUrls && hotel.imageUrls.length > 1 && (
              <>
                <button
                  onClick={handlePrevImage}
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  aria-label="Previous image"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                  onClick={handleNextImage}
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  aria-label="Next image"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 text-white px-3 py-1 rounded-full text-xs font-medium">
                  {currentImageIndex + 1} / {hotel.imageUrls.length}
                </div>
              </>
            )}
          </div>
          {hotel.imageUrls && hotel.imageUrls.length > 1 && (
            <div className="flex overflow-x-auto p-3 gap-3 bg-gray-50 border-t border-gray-100 scrollbar-hide">
              {hotel.imageUrls.map((url, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`flex-shrink-0 w-24 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                    currentImageIndex === index ? 'border-orange-500 shadow-md scale-105' : 'border-transparent opacity-60 hover:opacity-100 hover:scale-105'
                  }`}
                >
                  <img src={url} alt={`${hotel.name} - ${index + 1}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </button>
              ))}
            </div>
          )}
        </div>
        
        <div className="p-8 md:w-1/2 flex flex-col justify-center">
          <div className="flex justify-between items-start mb-4">
            <h1 className="text-3xl font-bold text-gray-900">{hotel.name}</h1>
            <div className="flex items-center bg-orange-100 px-3 py-1 rounded-lg">
              <Star className="w-5 h-5 text-orange-500 fill-current mr-1" />
              <span className="font-bold text-orange-700">{averageRating}</span>
            </div>
          </div>
          
          <p className="text-gray-700 leading-relaxed mb-6">{hotel.description}</p>
          
          <div className="mb-6">
            <h3 className="font-semibold text-gray-900 mb-2">Amenities</h3>
            <div className="flex flex-wrap gap-2">
              {hotel.amenities && hotel.amenities.length > 0 ? (
                hotel.amenities.map((amenity, index) => (
                  <span key={index} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                    {amenity}
                  </span>
                ))
              ) : (
                <span className="text-gray-500 text-sm">Basic amenities included</span>
              )}
            </div>
          </div>
          
          <div className="mt-auto">
            <div className="text-3xl font-bold text-orange-600 mb-1">₹{hotel.pricePerNight}</div>
            <div className="text-gray-500 text-sm">per night</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          {/* Reviews Section */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <MessageSquare className="w-6 h-6 mr-2 text-orange-500" />
              Reviews
            </h2>
            
            {user ? (
              <form onSubmit={handleSubmitReview} className="mb-8 bg-gray-50 p-6 rounded-xl border border-gray-100">
                <h3 className="font-semibold text-gray-900 mb-4">Write a Review</h3>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Rating</label>
                  <div className="flex space-x-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        className="focus:outline-none"
                      >
                        <Star className={`w-6 h-6 ${rating >= star ? 'text-orange-500 fill-current' : 'text-gray-300'}`} />
                      </button>
                    ))}
                  </div>
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Comment</label>
                  <textarea
                    required
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500 text-sm"
                    placeholder="Share your experience..."
                  ></textarea>
                </div>
                <button
                  type="submit"
                  disabled={submittingReview}
                  className="bg-orange-600 text-white py-2 px-6 rounded-lg font-medium hover:bg-orange-700 transition-colors disabled:opacity-50"
                >
                  {submittingReview ? 'Submitting...' : 'Submit Review'}
                </button>
              </form>
            ) : (
              <div className="mb-8 bg-orange-50 p-4 rounded-xl text-center">
                <p className="text-orange-800">Please login to write a review.</p>
              </div>
            )}

            <div className="space-y-6">
              {reviews.length > 0 ? (
                reviews.map((review) => (
                  <div key={review.id} className="border-b border-gray-100 last:border-0 pb-6 last:pb-0">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center">
                        <div className="bg-orange-100 p-2 rounded-full mr-3">
                          <User className="w-4 h-4 text-orange-600" />
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">{review.userName}</div>
                          <div className="text-xs text-gray-500">
                            {review.createdAt?.toDate ? review.createdAt.toDate().toLocaleDateString() : 'Just now'}
                          </div>
                        </div>
                      </div>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`w-4 h-4 ${i < review.rating ? 'text-orange-500 fill-current' : 'text-gray-300'}`} />
                        ))}
                      </div>
                    </div>
                    <p className="text-gray-700 mt-2">{review.comment}</p>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-4">No reviews yet. Be the first to review!</p>
              )}
            </div>
          </div>
        </div>

        <div>
          {/* Booking Form */}
          <div className="bg-white rounded-2xl shadow-lg p-6 sticky top-24">
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
              <Building className="w-5 h-5 mr-2 text-orange-500" />
              Book a Room
            </h3>
            
            <form onSubmit={handleRoomBooking} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Check-in Date</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <CalendarIcon className="w-4 h-4 text-gray-400" />
                  </div>
                  <input
                    type="date"
                    required
                    min={format(new Date(), 'yyyy-MM-dd')}
                    value={checkInDate}
                    onChange={(e) => setCheckInDate(e.target.value)}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-orange-500 focus:border-orange-500 text-sm"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Check-out Date</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <CalendarIcon className="w-4 h-4 text-gray-400" />
                  </div>
                  <input
                    type="date"
                    required
                    min={format(addDays(new Date(checkInDate), 1), 'yyyy-MM-dd')}
                    value={checkOutDate}
                    onChange={(e) => setCheckOutDate(e.target.value)}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-orange-500 focus:border-orange-500 text-sm"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Number of Rooms</label>
                <input
                  type="number"
                  required
                  min="1"
                  max="5"
                  value={numberOfRooms}
                  onChange={(e) => setNumberOfRooms(parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-orange-500 focus:border-orange-500 text-sm"
                />
              </div>
              
              <div className="pt-4 border-t border-gray-100 mt-6">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-gray-600">Total Price</span>
                  <span className="text-xl font-bold text-orange-600">
                    ₹{hotel.pricePerNight * Math.max(1, Math.ceil(Math.abs(new Date(checkOutDate).getTime() - new Date(checkInDate).getTime()) / (1000 * 60 * 60 * 24))) * numberOfRooms}
                  </span>
                </div>
                
                <button
                  type="submit"
                  disabled={roomBookingLoading || !user}
                  className="w-full bg-orange-600 text-white py-3 rounded-xl font-bold hover:bg-orange-700 transition-colors flex justify-center items-center disabled:opacity-50"
                >
                  {roomBookingLoading ? 'Processing...' : (
                    <>
                      <CreditCard className="w-5 h-5 mr-2" /> {user ? 'Pay & Book Now' : 'Login to Book'}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
