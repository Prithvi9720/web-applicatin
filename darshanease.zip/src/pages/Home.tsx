import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { Link } from 'react-router-dom';
import { MapPin, Clock } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export interface Temple {
  id: string;
  name: string;
  location: string;
  description: string;
  imageUrl: string;
  timings: string;
  createdAt: any;
}

export const Home = () => {
  const [temples, setTemples] = useState<Temple[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'temples'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const templeData = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        })) as Temple[];
        setTemples(templeData);
        setLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'temples');
      }
    );

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  return (
    <div>
      {/* Hero Section with Kedarnath Image */}
      <div className="relative rounded-3xl overflow-hidden mb-16 shadow-2xl">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1626261561081-37d800e97240?auto=format&fit=crop&w=1920&q=80"
            alt="Kedarnath Temple"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent"></div>
        </div>
        
        <div className="relative px-8 py-24 sm:px-16 sm:py-32 lg:px-24 lg:py-40 max-w-4xl">
          <h1 className="text-4xl font-extrabold text-white sm:text-5xl sm:tracking-tight lg:text-6xl mb-6">
            Explore Divine Destinations
          </h1>
          <p className="text-xl text-gray-200 max-w-2xl leading-relaxed">
            Experience spiritual bliss at sacred sites like Kedarnath. Book your darshan slots online seamlessly and focus on your devotion without the hassle.
          </p>
          <div className="mt-10">
            <a href="#temples" className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-xl text-orange-700 bg-white hover:bg-orange-50 transition-colors shadow-lg">
              View Temples
            </a>
          </div>
        </div>
      </div>

      <div id="temples" className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Available for Darshan</h2>
        <div className="w-20 h-1 bg-orange-500 rounded"></div>
      </div>

      {temples.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <p className="text-gray-500 text-lg">No temples found. Check back later!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {temples.map((temple) => (
            <div key={temple.id} className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <div className="relative h-48">
                <img
                  src={temple.imageUrl || 'https://picsum.photos/seed/temple/800/600'}
                  alt={temple.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <h3 className="absolute bottom-4 left-4 text-2xl font-bold text-white">{temple.name}</h3>
              </div>
              <div className="p-6">
                <div className="flex items-center text-gray-600 mb-2">
                  <MapPin className="w-4 h-4 mr-2 text-orange-500" />
                  <span className="text-sm">{temple.location}</span>
                </div>
                <div className="flex items-center text-gray-600 mb-4">
                  <Clock className="w-4 h-4 mr-2 text-orange-500" />
                  <span className="text-sm">{temple.timings}</span>
                </div>
                <p className="text-gray-600 text-sm line-clamp-3 mb-6">{temple.description}</p>
                <Link
                  to={`/temple/${temple.id}`}
                  className="block w-full text-center bg-orange-100 text-orange-700 hover:bg-orange-200 px-4 py-2 rounded-lg font-medium transition-colors"
                >
                  Book Darshan
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
