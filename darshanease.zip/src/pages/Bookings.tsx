import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Temple } from './Home';
import { Hotel } from './TempleDetails';
import { Calendar, Clock, MapPin, Users, XCircle, Building, CreditCard } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

interface Booking {
  id: string;
  templeId: string;
  date: string;
  timeSlot: string;
  numberOfPeople: number;
  status: 'confirmed' | 'cancelled';
  createdAt: any;
  temple?: Temple;
}

interface RoomBooking {
  id: string;
  hotelId: string;
  checkInDate: string;
  checkOutDate: string;
  numberOfRooms: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: any;
  hotel?: Hotel;
}

export const Bookings = () => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [roomBookings, setRoomBookings] = useState<RoomBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'darshan' | 'rooms'>('darshan');
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [bookingToCancel, setBookingToCancel] = useState<{ id: string, type: 'darshan' | 'room' } | null>(null);

  useEffect(() => {
    if (!user) return;

    // Fetch Darshan Bookings
    const q = query(collection(db, 'bookings'), where('userId', '==', user.uid));
    const unsubscribeDarshan = onSnapshot(
      q,
      async (snapshot) => {
        const bookingData = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        })) as Booking[];

        const bookingsWithTemples = await Promise.all(
          bookingData.map(async (booking) => {
            try {
              const templeDoc = await getDoc(doc(db, 'temples', booking.templeId));
              if (templeDoc.exists()) {
                return { ...booking, temple: { id: templeDoc.id, ...templeDoc.data() } as Temple };
              }
              return booking;
            } catch (error) {
              console.error("Error fetching temple details", error);
              return booking;
            }
          })
        );

        bookingsWithTemples.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setBookings(bookingsWithTemples);
        setLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'bookings');
      }
    );

    // Fetch Room Bookings
    const roomQ = query(collection(db, 'room_bookings'), where('userId', '==', user.uid));
    const unsubscribeRooms = onSnapshot(
      roomQ,
      async (snapshot) => {
        const roomBookingData = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        })) as RoomBooking[];

        const bookingsWithHotels = await Promise.all(
          roomBookingData.map(async (booking) => {
            try {
              const hotelDoc = await getDoc(doc(db, 'hotels', booking.hotelId));
              if (hotelDoc.exists()) {
                return { ...booking, hotel: { id: hotelDoc.id, ...hotelDoc.data() } as Hotel };
              }
              return booking;
            } catch (error) {
              console.error("Error fetching hotel details", error);
              return booking;
            }
          })
        );

        bookingsWithHotels.sort((a, b) => new Date(b.checkInDate).getTime() - new Date(a.checkInDate).getTime());
        setRoomBookings(bookingsWithHotels);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'room_bookings');
      }
    );

    return () => {
      unsubscribeDarshan();
      unsubscribeRooms();
    };
  }, [user]);

  const initiateCancel = (id: string, type: 'darshan' | 'room') => {
    setBookingToCancel({ id, type });
    setCancelModalOpen(true);
  };

  const confirmCancel = async () => {
    if (!bookingToCancel) return;
    try {
      if (bookingToCancel.type === 'darshan') {
        await updateDoc(doc(db, 'bookings', bookingToCancel.id), {
          status: 'cancelled'
        });
      } else {
        await updateDoc(doc(db, 'room_bookings', bookingToCancel.id), {
          status: 'cancelled'
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, bookingToCancel.type === 'darshan' ? `bookings/${bookingToCancel.id}` : `room_bookings/${bookingToCancel.id}`);
    } finally {
      setCancelModalOpen(false);
      setBookingToCancel(null);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">My Bookings</h1>

      <div className="flex space-x-4 mb-8 border-b border-gray-200">
        <button
          onClick={() => setActiveTab('darshan')}
          className={`pb-4 px-2 font-medium text-sm transition-colors relative ${
            activeTab === 'darshan' ? 'text-orange-600' : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Darshan Bookings
          {activeTab === 'darshan' && (
            <span className="absolute bottom-0 left-0 w-full h-0.5 bg-orange-600 rounded-t-full"></span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('rooms')}
          className={`pb-4 px-2 font-medium text-sm transition-colors relative ${
            activeTab === 'rooms' ? 'text-orange-600' : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Room Bookings
          {activeTab === 'rooms' && (
            <span className="absolute bottom-0 left-0 w-full h-0.5 bg-orange-600 rounded-t-full"></span>
          )}
        </button>
      </div>

      {activeTab === 'darshan' && (
        <>
          {bookings.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm p-12 text-center">
              <Calendar className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No darshan bookings yet</h3>
              <p className="text-gray-500">You haven't booked any darshan slots yet. Explore temples to make a booking.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {bookings.map((booking) => (
                <div key={booking.id} className="bg-white rounded-xl shadow-md overflow-hidden flex flex-col sm:flex-row">
                  <div className="sm:w-1/3 h-48 sm:h-auto relative">
                    <img
                      src={booking.temple?.imageUrl || 'https://picsum.photos/seed/temple/800/600'}
                      alt={booking.temple?.name || 'Temple'}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                      booking.status === 'confirmed' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {booking.status}
                    </div>
                  </div>
                  
                  <div className="p-6 sm:w-2/3 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">
                        {booking.temple?.name || 'Unknown Temple'}
                      </h3>
                      <div className="flex items-center text-gray-600 mb-4 text-sm">
                        <MapPin className="w-4 h-4 mr-1 text-orange-500" />
                        {booking.temple?.location || 'Unknown Location'}
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="flex items-center text-gray-700">
                          <Calendar className="w-5 h-5 mr-2 text-orange-500" />
                          <span className="font-medium">{new Date(booking.date).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center text-gray-700">
                          <Clock className="w-5 h-5 mr-2 text-orange-500" />
                          <span className="font-medium">{booking.timeSlot}</span>
                        </div>
                        <div className="flex items-center text-gray-700 col-span-2">
                          <Users className="w-5 h-5 mr-2 text-orange-500" />
                          <span className="font-medium">{booking.numberOfPeople} Person(s)</span>
                        </div>
                      </div>
                    </div>
                    
                    {booking.status === 'confirmed' && new Date(booking.date) >= new Date(new Date().setHours(0,0,0,0)) && (
                      <div className="mt-4 pt-4 border-t border-gray-100 flex justify-end">
                        <button
                          onClick={() => initiateCancel(booking.id, 'darshan')}
                          className="flex items-center text-red-600 hover:text-red-800 font-medium text-sm transition-colors"
                        >
                          <XCircle className="w-4 h-4 mr-1" /> Cancel Booking
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {activeTab === 'rooms' && (
        <>
          {roomBookings.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm p-12 text-center">
              <Building className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No room bookings yet</h3>
              <p className="text-gray-500">You haven't booked any rooms yet. Explore temples to find nearby hotels.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {roomBookings.map((booking) => (
                <div key={booking.id} className="bg-white rounded-xl shadow-md overflow-hidden flex flex-col sm:flex-row">
                  <div className="sm:w-1/3 h-48 sm:h-auto relative">
                    <img
                      src={booking.hotel?.imageUrl || 'https://picsum.photos/seed/hotel/800/600'}
                      alt={booking.hotel?.name || 'Hotel'}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                      booking.status === 'confirmed' ? 'bg-green-100 text-green-800' : 
                      booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {booking.status}
                    </div>
                  </div>
                  
                  <div className="p-6 sm:w-2/3 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">
                        {booking.hotel?.name || 'Unknown Hotel'}
                      </h3>
                      
                      <div className="grid grid-cols-2 gap-4 mb-4 mt-4">
                        <div className="flex items-center text-gray-700">
                          <Calendar className="w-5 h-5 mr-2 text-orange-500" />
                          <div>
                            <span className="text-xs text-gray-500 block">Check-in</span>
                            <span className="font-medium">{new Date(booking.checkInDate).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <div className="flex items-center text-gray-700">
                          <Calendar className="w-5 h-5 mr-2 text-orange-500" />
                          <div>
                            <span className="text-xs text-gray-500 block">Check-out</span>
                            <span className="font-medium">{new Date(booking.checkOutDate).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <div className="flex items-center text-gray-700">
                          <Building className="w-5 h-5 mr-2 text-orange-500" />
                          <span className="font-medium">{booking.numberOfRooms} Room(s)</span>
                        </div>
                        <div className="flex items-center text-gray-700">
                          <CreditCard className="w-5 h-5 mr-2 text-orange-500" />
                          <span className="font-bold text-orange-600">₹{booking.totalPrice}</span>
                        </div>
                      </div>
                    </div>
                    
                    {(booking.status === 'confirmed' || booking.status === 'pending') && new Date(booking.checkInDate) >= new Date(new Date().setHours(0,0,0,0)) && (
                      <div className="mt-4 pt-4 border-t border-gray-100 flex justify-end">
                        <button
                          onClick={() => initiateCancel(booking.id, 'room')}
                          className="flex items-center text-red-600 hover:text-red-800 font-medium text-sm transition-colors"
                        >
                          <XCircle className="w-4 h-4 mr-1" /> Cancel Booking
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {cancelModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Cancel Booking</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to cancel this {bookingToCancel?.type === 'room' ? 'room' : 'darshan'} booking? This action cannot be undone.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => {
                  setCancelModalOpen(false);
                  setBookingToCancel(null);
                }}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 font-medium transition-colors"
              >
                Keep Booking
              </button>
              <button
                onClick={confirmCancel}
                className="px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-colors"
              >
                Yes, Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
