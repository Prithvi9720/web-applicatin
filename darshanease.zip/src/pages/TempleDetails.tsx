import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, addDoc, serverTimestamp, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Temple } from './Home';
import { Calendar as CalendarIcon, Clock, Users, MapPin, ArrowLeft, Building } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { format, addDays } from 'date-fns';

declare global {
  interface Window {
    Stripe: any;
  }
}

export interface Hotel {
  id: string;
  templeId: string;
  name: string;
  description: string;
  imageUrls: string[];
  pricePerNight: number;
}

export const TempleDetails = () => {
  const { id } = useParams<{ id: string }>();
  const [temple, setTemple] = useState<Temple | null>(null);
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  const [date, setDate] = useState(format(addDays(new Date(), 1), 'yyyy-MM-dd'));
  const [timeSlot, setTimeSlot] = useState('08:00 AM - 10:00 AM');
  const [numberOfPeople, setNumberOfPeople] = useState(1);
  const [bookingLoading, setBookingLoading] = useState(false);

  const timeSlots = [
    '06:00 AM - 08:00 AM',
    '08:00 AM - 10:00 AM',
    '10:00 AM - 12:00 PM',
    '04:00 PM - 06:00 PM',
    '06:00 PM - 08:00 PM',
  ];

  useEffect(() => {
    const fetchData = async () => {
      if (!id) return;
      try {
        // Fetch temple
        const docRef = doc(db, 'temples', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setTemple({ id: docSnap.id, ...docSnap.data() } as Temple);
        }

        // Fetch hotels
        const hotelsQuery = query(collection(db, 'hotels'), where('templeId', '==', id));
        const hotelsSnap = await getDocs(hotelsQuery);
        const hotelsData = hotelsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Hotel));
        setHotels(hotelsData);
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `temples/${id} or hotels`);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id]);

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert('Please login to book darshan.');
      return;
    }
    if (!id) return;

    setBookingLoading(true);
    try {
      await addDoc(collection(db, 'bookings'), {
        userId: user.uid,
        templeId: id,
        date,
        timeSlot,
        numberOfPeople,
        status: 'confirmed',
        createdAt: serverTimestamp(),
      });
      alert('Darshan booked successfully!');
      navigate('/bookings');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'bookings');
    } finally {
      setBookingLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  if (!temple) {
    return <div className="text-center py-12 text-gray-500">Temple not found.</div>;
  }

  return (
    <div className="max-w-5xl mx-auto">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center text-orange-600 hover:text-orange-800 mb-6 font-medium"
      >
        <ArrowLeft className="w-4 h-4 mr-1" /> Back
      </button>

      <div className="bg-white rounded-2xl shadow-lg overflow-hidden flex flex-col md:flex-row">
        <div className="md:w-1/2 h-64 md:h-auto relative">
          <img
            src={temple.imageUrl || 'https://picsum.photos/seed/temple/800/600'}
            alt={temple.name}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        
        <div className="p-8 md:w-1/2 flex flex-col justify-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">{temple.name}</h1>
          
          <div className="space-y-3 mb-6">
            <div className="flex items-center text-gray-600">
              <MapPin className="w-5 h-5 mr-3 text-orange-500" />
              <span>{temple.location}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <Clock className="w-5 h-5 mr-3 text-orange-500" />
              <span>{temple.timings}</span>
            </div>
          </div>
          
          <p className="text-gray-700 leading-relaxed mb-8">{temple.description}</p>
        </div>
      </div>

      <div className="mt-12 bg-white rounded-2xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Book Darshan</h2>
        
        <form onSubmit={handleBooking} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                <CalendarIcon className="w-4 h-4 mr-2 text-orange-500" /> Date
              </label>
              <input
                type="date"
                required
                min={format(new Date(), 'yyyy-MM-dd')}
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                <Clock className="w-4 h-4 mr-2 text-orange-500" /> Time Slot
              </label>
              <select
                value={timeSlot}
                onChange={(e) => setTimeSlot(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              >
                {timeSlots.map((slot) => (
                  <option key={slot} value={slot}>{slot}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                <Users className="w-4 h-4 mr-2 text-orange-500" /> Number of People
              </label>
              <input
                type="number"
                required
                min="1"
                max="10"
                value={numberOfPeople}
                onChange={(e) => setNumberOfPeople(parseInt(e.target.value))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
          </div>

          <div className="pt-4">
            <button
              type="submit"
              disabled={bookingLoading || !user}
              className="w-full bg-orange-600 text-white py-3 px-6 rounded-xl font-bold text-lg hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {bookingLoading ? 'Booking...' : user ? 'Confirm Booking' : 'Login to Book'}
            </button>
            {!user && (
              <p className="text-center text-sm text-gray-500 mt-2">
                You must be logged in to book a darshan slot.
              </p>
            )}
          </div>
        </form>
      </div>

      {hotels.length > 0 && (
        <div className="mt-12 bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <Building className="w-6 h-6 mr-2 text-orange-500" />
            Hotels Near {temple.name}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {hotels.map((hotel) => (
              <div key={hotel.id} className="border border-gray-200 rounded-xl overflow-hidden flex flex-col">
                <div className="h-48 w-full relative">
                  <img
                    src={hotel.imageUrls && hotel.imageUrls.length > 0 ? hotel.imageUrls[0] : `https://picsum.photos/seed/${hotel.name.replace(/\s+/g, '')}/800/600`}
                    alt={hotel.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-6 flex flex-col flex-grow">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{hotel.name}</h3>
                      <p className="text-gray-500 text-sm mt-1 line-clamp-2">{hotel.description}</p>
                    </div>
                    <div className="text-right ml-4 flex-shrink-0">
                      <span className="text-2xl font-bold text-orange-600">₹{hotel.pricePerNight}</span>
                      <span className="text-gray-500 text-sm block">per night</span>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => navigate(`/hotel/${hotel.id}`)}
                    className="mt-auto w-full bg-orange-100 text-orange-700 py-2 rounded-lg font-medium hover:bg-orange-200 transition-colors"
                  >
                    View Details & Book
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
