import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { CheckCircle, XCircle } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export const PaymentSuccess = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const sessionId = searchParams.get('session_id');
  const bookingId = searchParams.get('booking_id');
  const type = searchParams.get('type');

  useEffect(() => {
    const confirmPayment = async () => {
      if (!sessionId || !bookingId || type !== 'room') {
        setStatus('error');
        return;
      }

      try {
        const bookingRef = doc(db, 'room_bookings', bookingId);
        await updateDoc(bookingRef, {
          status: 'confirmed',
        });
        setStatus('success');
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `room_bookings/${bookingId}`);
        setStatus('error');
      }
    };

    confirmPayment();
  }, [sessionId, bookingId, type]);

  if (status === 'loading') {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div className="max-w-md mx-auto mt-12 bg-white rounded-2xl shadow-lg p-8 text-center">
        <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Payment Verification Failed</h2>
        <p className="text-gray-600 mb-6">There was an issue verifying your payment. Please contact support.</p>
        <button
          onClick={() => navigate('/')}
          className="bg-orange-600 text-white py-2 px-6 rounded-xl font-bold hover:bg-orange-700 transition-colors"
        >
          Return Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto mt-12 bg-white rounded-2xl shadow-lg p-8 text-center">
      <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
      <h2 className="text-2xl font-bold text-gray-900 mb-2">Payment Successful!</h2>
      <p className="text-gray-600 mb-6">Your room booking has been confirmed.</p>
      <button
        onClick={() => navigate('/bookings')}
        className="bg-orange-600 text-white py-2 px-6 rounded-xl font-bold hover:bg-orange-700 transition-colors"
      >
        View My Bookings
      </button>
    </div>
  );
};
