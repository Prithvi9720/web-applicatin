import React, { useState, useEffect } from 'react';
import { collection, addDoc, serverTimestamp, onSnapshot, query, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Temple } from './Home';
import { Plus, Trash2, Edit, Database, Building } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export interface Hotel {
  id: string;
  templeId: string;
  name: string;
  description: string;
  imageUrls: string[];
  pricePerNight: number;
  amenities?: string[];
  createdAt: any;
}

const sampleTemples = [
  {
    name: "Kashi Vishwanath Temple",
    location: "Varanasi, Uttar Pradesh",
    description: "One of the most famous Hindu temples dedicated to Lord Shiva. It is located in Varanasi, Uttar Pradesh, India. The temple stands on the western bank of the holy river Ganga, and is one of the twelve Jyotirlingas.",
    imageUrl: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?auto=format&fit=crop&w=800&q=80",
    timings: "03:00 AM - 11:00 PM"
  },
  {
    name: "Tirupati Balaji",
    location: "Tirumala, Andhra Pradesh",
    description: "Sri Venkateswara Swami Vaari Temple is a Hindu temple situated in the hill town of Tirumala at Tirupati in Tirupati district of Andhra Pradesh, India. The Temple is dedicated to Venkateswara, a form of Vishnu.",
    imageUrl: "https://images.unsplash.com/photo-1623059405215-58d3437015f6?auto=format&fit=crop&w=800&q=80",
    timings: "06:00 AM - 12:00 AM"
  },
  {
    name: "Meenakshi Amman Temple",
    location: "Madurai, Tamil Nadu",
    description: "A historic Hindu temple located on the southern bank of the Vaigai River in the temple city of Madurai, Tamil Nadu, India. It is dedicated to the goddess Meenakshi, a form of Parvati, and her consort, Sundareshwarar, a form of Shiva.",
    imageUrl: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=800&q=80",
    timings: "05:00 AM - 10:00 PM"
  },
  {
    name: "Golden Temple (Harmandir Sahib)",
    location: "Amritsar, Punjab",
    description: "The Golden Temple is the preeminent spiritual site of Sikhism. It is an open house of worship for all people, from all walks of life and faiths.",
    imageUrl: "https://images.unsplash.com/photo-1587550005716-17b53112c224?auto=format&fit=crop&w=800&q=80",
    timings: "Open 24 Hours"
  },
  {
    name: "Jagannath Temple",
    location: "Puri, Odisha",
    description: "An important Hindu temple dedicated to Jagannath, a form of Vishnu, in Puri in the state of Odisha on the eastern coast of India. The present temple was rebuilt from the 10th century onwards.",
    imageUrl: "https://images.unsplash.com/photo-1610017810004-a6f3c531df34?auto=format&fit=crop&w=800&q=80",
    timings: "05:00 AM - 11:00 PM"
  },
  {
    name: "Kedarnath Temple",
    location: "Kedarnath, Uttarakhand",
    description: "A Hindu temple dedicated to Lord Shiva. Located on the Garhwal Himalayan range near the Mandakini river, Kedarnath is located in the state of Uttarakhand, India.",
    imageUrl: "https://images.unsplash.com/photo-1626261561081-37d800e97240?auto=format&fit=crop&w=800&q=80",
    timings: "04:00 AM - 09:00 PM"
  }
];

export const Admin = () => {
  const { role } = useAuth();
  const navigate = useNavigate();
  const [temples, setTemples] = useState<Temple[]>([]);
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSeeding, setIsSeeding] = useState(false);
  const [activeTab, setActiveTab] = useState<'temples' | 'hotels'>('temples');

  // Temple Form state
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [timings, setTimings] = useState('');
  
  // Hotel Form state
  const [hotelName, setHotelName] = useState('');
  const [hotelDescription, setHotelDescription] = useState('');
  const [hotelImageUrl, setHotelImageUrl] = useState('');
  const [hotelPrice, setHotelPrice] = useState('');
  const [selectedTempleId, setSelectedTempleId] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (role !== 'admin') {
      navigate('/');
      return;
    }

    const qTemples = query(collection(db, 'temples'), orderBy('createdAt', 'desc'));
    const unsubscribeTemples = onSnapshot(
      qTemples,
      (snapshot) => {
        const templeData = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        })) as Temple[];
        setTemples(templeData);
        if (templeData.length > 0 && !selectedTempleId) {
          setSelectedTempleId(templeData[0].id);
        }
        setLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'temples');
      }
    );

    const qHotels = query(collection(db, 'hotels'), orderBy('createdAt', 'desc'));
    const unsubscribeHotels = onSnapshot(
      qHotels,
      (snapshot) => {
        const hotelData = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        })) as Hotel[];
        setHotels(hotelData);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'hotels');
      }
    );

    return () => {
      unsubscribeTemples();
      unsubscribeHotels();
    };
  }, [role, navigate]);

  const handleAddTemple = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'temples'), {
        name,
        location,
        description,
        imageUrl: imageUrl || `https://picsum.photos/seed/${name.replace(/\s+/g, '')}/800/600`,
        timings,
        createdAt: serverTimestamp(),
      });
      // Reset form
      setName('');
      setLocation('');
      setDescription('');
      setImageUrl('');
      setTimings('');
      alert('Temple added successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'temples');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddHotel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTempleId) {
      alert('Please select a temple first.');
      return;
    }
    setIsSubmitting(true);
    try {
      const urls = hotelImageUrl.split(',').map(url => url.trim()).filter(url => url !== '');
      await addDoc(collection(db, 'hotels'), {
        templeId: selectedTempleId,
        name: hotelName,
        description: hotelDescription,
        imageUrls: urls.length > 0 ? urls : [`https://picsum.photos/seed/${hotelName.replace(/\s+/g, '')}/800/600`],
        pricePerNight: Number(hotelPrice),
        createdAt: serverTimestamp(),
      });
      // Reset form
      setHotelName('');
      setHotelDescription('');
      setHotelImageUrl('');
      setHotelPrice('');
      alert('Hotel added successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'hotels');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteTemple = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this temple?')) return;
    try {
      await deleteDoc(doc(db, 'temples', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `temples/${id}`);
    }
  };

  const handleDeleteHotel = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this hotel?')) return;
    try {
      await deleteDoc(doc(db, 'hotels', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `hotels/${id}`);
    }
  };

  const handleSeedTemples = async () => {
    if (!window.confirm('This will add sample temples to the database. Continue?')) return;
    setIsSeeding(true);
    try {
      for (const temple of sampleTemples) {
        await addDoc(collection(db, 'temples'), {
          ...temple,
          createdAt: serverTimestamp(),
        });
      }
      alert('Sample temples added successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'temples');
    } finally {
      setIsSeeding(false);
    }
  };

  if (role !== 'admin') return null;

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
        <div className="flex space-x-4">
          <button
            onClick={() => setActiveTab('temples')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${activeTab === 'temples' ? 'bg-orange-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
          >
            Manage Temples
          </button>
          <button
            onClick={() => setActiveTab('hotels')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${activeTab === 'hotels' ? 'bg-orange-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
          >
            Manage Hotels
          </button>
          {activeTab === 'temples' && (
            <button
              onClick={handleSeedTemples}
              disabled={isSeeding}
              className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 transition-colors"
            >
              <Database className="w-4 h-4 mr-2" />
              {isSeeding ? 'Seeding...' : 'Seed Sample Temples'}
            </button>
          )}
        </div>
      </div>

      {activeTab === 'temples' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Add Temple Form */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-md p-6 sticky top-24">
              <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                <Plus className="w-5 h-5 mr-2 text-orange-500" /> Add New Temple
              </h2>
              
              <form onSubmit={handleAddTemple} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Temple Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="e.g., Kashi Vishwanath"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="e.g., Varanasi, Uttar Pradesh"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Timings</label>
                  <input
                    type="text"
                    required
                    value={timings}
                    onChange={(e) => setTimings(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="e.g., 04:00 AM - 11:00 PM"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Image URL (Optional)</label>
                  <input
                    type="url"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea
                    required
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Brief description of the temple..."
                  ></textarea>
                </div>
                
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-orange-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50 transition-colors"
                >
                  {isSubmitting ? 'Adding...' : 'Add Temple'}
                </button>
              </form>
            </div>
          </div>

          {/* Manage Temples List */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Manage Temples</h2>
              
              {loading ? (
                <div className="flex justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600"></div>
                </div>
              ) : temples.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No temples added yet.</p>
              ) : (
                <div className="space-y-4">
                  {temples.map((temple) => (
                    <div key={temple.id} className="border border-gray-200 rounded-xl p-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <img
                          src={temple.imageUrl}
                          alt={temple.name}
                          className="w-16 h-16 rounded-lg object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <h3 className="font-bold text-gray-900">{temple.name}</h3>
                          <p className="text-sm text-gray-500">{temple.location}</p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleDeleteTemple(temple.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Temple"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Add Hotel Form */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-md p-6 sticky top-24">
              <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                <Building className="w-5 h-5 mr-2 text-orange-500" /> Add New Hotel
              </h2>
              
              <form onSubmit={handleAddHotel} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Select Temple</label>
                  <select
                    required
                    value={selectedTempleId}
                    onChange={(e) => setSelectedTempleId(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  >
                    <option value="" disabled>Select a temple</option>
                    {temples.map(t => (
                      <option key={t.id} value={t.id}>{t.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Hotel Name</label>
                  <input
                    type="text"
                    required
                    value={hotelName}
                    onChange={(e) => setHotelName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="e.g., Grand Stay"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Price per Night (INR)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={hotelPrice}
                    onChange={(e) => setHotelPrice(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="e.g., 2500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Image URLs (Optional, comma separated)</label>
                  <input
                    type="text"
                    value={hotelImageUrl}
                    onChange={(e) => setHotelImageUrl(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="https://example.com/hotel1.jpg, https://example.com/hotel2.jpg"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea
                    required
                    rows={4}
                    value={hotelDescription}
                    onChange={(e) => setHotelDescription(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Brief description of the hotel..."
                  ></textarea>
                </div>
                
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-orange-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50 transition-colors"
                >
                  {isSubmitting ? 'Adding...' : 'Add Hotel'}
                </button>
              </form>
            </div>
          </div>

          {/* Manage Hotels List */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Manage Hotels</h2>
              
              {loading ? (
                <div className="flex justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600"></div>
                </div>
              ) : hotels.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No hotels added yet.</p>
              ) : (
                <div className="space-y-4">
                  {hotels.map((hotel) => {
                    const temple = temples.find(t => t.id === hotel.templeId);
                    return (
                      <div key={hotel.id} className="border border-gray-200 rounded-xl p-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
                        <div className="flex items-center space-x-4">
                          <img
                            src={hotel.imageUrls && hotel.imageUrls.length > 0 ? hotel.imageUrls[0] : `https://picsum.photos/seed/${hotel.name.replace(/\s+/g, '')}/800/600`}
                            alt={hotel.name}
                            className="w-16 h-16 rounded-lg object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <h3 className="font-bold text-gray-900">{hotel.name}</h3>
                            <p className="text-sm text-gray-500">Near: {temple?.name || 'Unknown Temple'}</p>
                            <p className="text-sm font-medium text-orange-600">₹{hotel.pricePerNight} / night</p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleDeleteHotel(hotel.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Delete Hotel"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
