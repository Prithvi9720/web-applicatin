import React from 'react';
import { useNavigate } from 'react-router-dom';
import { XCircle } from 'lucide-react';

export const PaymentCancelled = () => {
  const navigate = useNavigate();

  return (
    <div className="max-w-md mx-auto mt-12 bg-white rounded-2xl shadow-lg p-8 text-center">
      <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
      <h2 className="text-2xl font-bold text-gray-900 mb-2">Payment Cancelled</h2>
      <p className="text-gray-600 mb-6">Your payment was cancelled and no charges were made.</p>
      <button
        onClick={() => navigate(-1)}
        className="bg-orange-600 text-white py-2 px-6 rounded-xl font-bold hover:bg-orange-700 transition-colors"
      >
        Go Back
      </button>
    </div>
  );
};
