import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { signInWithGoogle, logOut } from './firebase';
import { Home } from './pages/Home';
import { TempleDetails } from './pages/TempleDetails';
import { HotelDetails } from './pages/HotelDetails';
import { Bookings } from './pages/Bookings';
import { Admin } from './pages/Admin';
import { PaymentSuccess } from './pages/PaymentSuccess';
import { PaymentCancelled } from './pages/PaymentCancelled';
import { LogIn, LogOut, User, Calendar, Settings, Home as HomeIcon } from 'lucide-react';

const Navbar = () => {
  const { user, role } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      await signInWithGoogle();
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  const handleLogout = async () => {
    try {
      await logOut();
      navigate('/');
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  return (
    <nav className="bg-orange-600 text-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2 text-xl font-bold">
              <span className="text-2xl">🕉️</span>
              <span>DarshanEase</span>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Link to="/" className="hover:text-orange-200 px-3 py-2 rounded-md text-sm font-medium flex items-center">
              <HomeIcon className="w-4 h-4 mr-1" /> Home
            </Link>
            {user ? (
              <>
                <Link to="/bookings" className="hover:text-orange-200 px-3 py-2 rounded-md text-sm font-medium flex items-center">
                  <Calendar className="w-4 h-4 mr-1" /> My Bookings
                </Link>
                {role === 'admin' && (
                  <Link to="/admin" className="hover:text-orange-200 px-3 py-2 rounded-md text-sm font-medium flex items-center">
                    <Settings className="w-4 h-4 mr-1" /> Admin
                  </Link>
                )}
                <div className="flex items-center space-x-2 ml-4 pl-4 border-l border-orange-500">
                  <span className="text-sm font-medium hidden sm:block">{user.displayName}</span>
                  <button
                    onClick={handleLogout}
                    className="bg-orange-700 hover:bg-orange-800 px-4 py-2 rounded-lg text-sm font-medium flex items-center transition-colors"
                  >
                    <LogOut className="w-4 h-4 mr-2" /> Logout
                  </button>
                </div>
              </>
            ) : (
              <button
                onClick={handleLogin}
                className="bg-white text-orange-600 hover:bg-orange-50 px-4 py-2 rounded-lg text-sm font-medium flex items-center transition-colors"
              >
                <LogIn className="w-4 h-4 mr-2" /> Login
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Router>
          <div className="min-h-screen bg-orange-50 font-sans">
            <Navbar />
            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/temple/:id" element={<TempleDetails />} />
                <Route path="/hotel/:id" element={<HotelDetails />} />
                <Route path="/bookings" element={<Bookings />} />
                <Route path="/admin" element={<Admin />} />
                <Route path="/payment-success" element={<PaymentSuccess />} />
                <Route path="/payment-cancelled" element={<PaymentCancelled />} />
              </Routes>
            </main>
          </div>
        </Router>
      </AuthProvider>
    </ErrorBoundary>
  );
}
